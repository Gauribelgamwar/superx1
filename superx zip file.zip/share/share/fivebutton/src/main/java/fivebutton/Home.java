package fivebutton;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Home extends Application{
    
   

Stage primaryStage;
Scene homeScene,secondScene;                   
public void back(){

    primaryStage.setScene(homeScene);

}
    private void initialization(Button btn){
        int id =Integer.parseInt(btn.getId());
        VBox vb;
        Scene sc ;
        switch(id){

            case 1:
            One one = new One();
            vb = one.createScene(this::back);
                    vb.setStyle("-fx-background-color:lightblue");

            sc = new Scene(vb,500,500);
            secondScene = sc;
            break;

            case 2:
            One two = new One();
            vb = two.createScene(this::back);
            vb.setStyle("-fx-background-color:yellow");

            
            sc = new Scene(vb,500,500);
            secondScene = sc;

            break;

            case 3:
           Three three  = new Three();
            vb = three.createScene(this::back);
                    vb.setStyle("-fx-background-color:maroon");

            sc = new Scene(vb,500,500);
            secondScene = sc;
            break;

            case 4:
            Four four = new Four();
            vb = four.createScene(this::back);
            vb.setStyle("-fx-background-color:grey");

            
            sc = new Scene(vb,500,500);
            secondScene = sc;

            break;
            case 5:
            Five five = new Five();
            vb = five.createScene(this::back);
            vb.setStyle("-fx-background-color:pink");

            
            sc = new Scene(vb,500,500);
            secondScene = sc;

            break;



        } 


    }
    @Override
    public void start(Stage stage)throws Exception{
 
    

    Button btn1 = new Button("One");
    btn1.setId("1");
        Button btn2 = new Button("Two");
btn2.setId("2");
            Button btn3 = new Button("Three");
btn3.setId("3");
                Button btn4 = new Button("Four");
btn4.setId("4");
                    Button btn5 = new Button("Five");

btn5.setId("5");


btn1.setOnAction(new EventHandler<ActionEvent>() {

    @Override
    public void handle(ActionEvent arg0) {
       
    initialization(btn1);

    primaryStage.setScene(secondScene);

    }
    
});


btn2.setOnAction(new EventHandler<ActionEvent>() {

    @Override
    public void handle(ActionEvent arg0) {
       
    initialization(btn2);

    primaryStage.setScene(secondScene);

    }
    
});

btn3.setOnAction(new EventHandler<ActionEvent>() {

    @Override
    public void handle(ActionEvent arg0) {
       
    initialization(btn3);

    primaryStage.setScene(secondScene);

    }
    
});

btn4.setOnAction(new EventHandler<ActionEvent>() {

    @Override
    public void handle(ActionEvent arg0) {
       
    initialization(btn4);

    primaryStage.setScene(secondScene);

    }
    
});

btn5.setOnAction(new EventHandler<ActionEvent>() {

    @Override
    public void handle(ActionEvent arg0) {
       
    initialization(btn5);

    primaryStage.setScene(secondScene);

    }
    
});

        VBox  vb = new VBox(40,btn1,btn2,btn3,btn4,btn5);
        vb.setAlignment(Pos.CENTER);
        Scene sc = new Scene(vb,500,500);
        homeScene = sc;

        primaryStage = stage;

        primaryStage.setScene(homeScene);
        stage.show();
    
        
        btn1.setStyle("-fx-background-color:grey");
                btn2.setStyle("-fx-background-color:pink");
                btn3.setStyle("-fx-background-color:grey");
                btn4.setStyle("-fx-background-color:pink");
                btn5.setStyle("-fx-background-color:grey");
                


    }

    
    
    
}
