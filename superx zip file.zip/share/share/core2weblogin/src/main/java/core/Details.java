package core;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

public class Details {
    public VBox createScene(Runnable back,Info info){

        Text txt = new Text();

        Text user = new Text();

        Text pass = new Text();

        user.setText(info.getUsername());
        pass.setText(info.getPassword());
        txt.setText("Welcome "+txt.getText());
        Button backBtn = new Button("Back");



        backBtn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent arg0) {

                back.run();
                
               
            }
            
        });





        VBox vb = new VBox(50,user,pass,backBtn);
        vb.setStyle("-fx-background-color:pink");
        vb.setAlignment(Pos.CENTER);
        return vb;


    }
    
}
