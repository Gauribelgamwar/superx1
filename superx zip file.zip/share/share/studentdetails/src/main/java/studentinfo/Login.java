package studentinfo;



import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Login extends Application{
    Scene scenePage1,scenePage2;
    Stage primaryStage;
    public Scene getScenePage1() {
        return scenePage1;
    }

    public void setScenePage1(Scene scenePage1) {
        this.scenePage1 = scenePage1;
    }

    public Scene getScenePage2() {
        return scenePage2;
    }

    public void setScenePage2(Scene scenePage2) {
        this.scenePage2 = scenePage2;
    }

    public Stage getPrimaryStage() {
        return primaryStage;
    }

    public void setPrimaryStage(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }

    



    public void start(Stage stage){

        Text txt = new Text("page1");

        Button nextButton = new Button("next page");

        nextButton.setOnAction(new EventHandler <ActionEvent> () {

            @Override
            public void handle(ActionEvent arg0) {
                initialize();
                primaryStage.setScene(scenePage2);

                
            }});


        VBox vb = new VBox(txt,nextButton);
        scenePage1 = new Scene(vb,500,500);
        primaryStage = stage;
        primaryStage.setScene(scenePage1);
        




        stage.show();
    }

 private void back(){

    primaryStage.setScene(scenePage1);
 }

    private void initialize(){
        Details details = new Details();
         VBox vb = details.createScene(this::back);
         Scene sc = new Scene(vb,500,500);
         setScenePage2(sc);
         

    }


    

    
}
