package studentinfo;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Details {
    Stage stage;
    Scene scene;
    public Stage getStage() {
        return stage;
    }
    public void setStage(Stage stage) {
        this.stage = stage;
    }
    public Scene getScene() {
        return scene;
    }
    public void setScene(Scene scene) {
        this.scene = scene;
    }

    public VBox createScene(Runnable backMethod){
        VBox vb = new VBox(50);
        Text txt  = new Text("Details Page");
        Button prevButton = new Button("Prev Button");

        prevButton.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event){
                backMethod.run();
                
            }
        });
        vb.getChildren().addAll(txt,prevButton);

        return vb;
    }



    
}
