package com.api;

import javafx.application.Application;
import javafx.stage.Stage;

public class home extends Application {

    @Override
    public void start(Stage arg0) throws Exception {
       
    }
    
}
