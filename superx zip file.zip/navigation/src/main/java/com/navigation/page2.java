package com.navigation;


import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class page2 extends Application {

    Stage mainStage;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        mainStage = primaryStage;

        showLoginScreen();
    }

    void showLoginScreen() {
        Label userLabel = new Label("User Name:");
        TextField userField = new TextField();

        Label passLabel = new Label("Password:");
        PasswordField passField = new PasswordField();

        Button loginBtn = new Button("Sign in");
        Label messageLabel = new Label();

        loginBtn.setOnAction(e -> {
            String username = userField.getText();
            String password = passField.getText();

           
            if (!username.isEmpty() && password.startsWith("c2w") && password.length() >= 8) {
                showWelcomeScreen(username);
            } else {
                messageLabel.setText("Invalid inputs");
            }
        });

        VBox vbox = new VBox(10, userLabel, userField, passLabel, passField, loginBtn, messageLabel);
        vbox.setStyle("-fx-padding: 20; -fx-alignment: center;");
        Scene scene = new Scene(vbox, 300, 250);

        mainStage.setTitle("Login Page");
        mainStage.setScene(scene);
        mainStage.show();
    }

    void showWelcomeScreen(String username) {
        Label welcomeLabel = new Label("Welcome " + username + "!!");
        Button logoutBtn = new Button("Logout");

        logoutBtn.setOnAction(e -> showLoginScreen());

        VBox vbox = new VBox(20, welcomeLabel, logoutBtn);
        vbox.setStyle("-fx-padding: 20; -fx-alignment: center;");
        Scene welcomeScene = new Scene(vbox, 1000, 800);

        mainStage.setScene(welcomeScene);
    }
}
    

