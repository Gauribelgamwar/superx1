package com.login1;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class home extends Application {

    Scene homeScene;
    Stage primaryStage;
    public Object sc;
    
    @Override
    public void start(Stage arg0) throws Exception {

        Text tx = new Text("welcome to core2web");

        Label userLabel = new Label("User Name:");
        TextField userField = new TextField();

        Label passLabel = new Label("Password:");
        PasswordField passField = new PasswordField();

        Button signIn = new Button("Sign In");
        Label message = new Label();

        signIn.setOnAction(e -> {
            String user = userField.getText();
            String pass = passField.getText();

            if (!user.isEmpty() && pass.startsWith("c2w") && pass.length() >= 8) {
                
              tx.setText("Login Sucessflullly");

            } else {
                tx.setText("Invalid inputs");
            }
        });

        VBox layout = new VBox(10, userLabel, userField, passLabel, passField, signIn, tx);
        layout.setStyle("-fx-padding: 20; -fx-alignment: center;");
        Scene scene = new Scene(layout, 800, 650);
        arg0.setScene(scene);
        arg0.show();
    


        Button nxtBtn = new Button("login");
        nxtBtn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent arg0) {
                initializeloginpage();
                primaryStage.setScene(homeScene);
            }

       
    });

     VBox vb = new VBox(50,tx,nxtBtn);
        vb.setAlignment(Pos.CENTER);
        Scene sc = new Scene(vb,800,500);
        arg0.setScene(sc);
        homeScene = sc;
        primaryStage = arg0;
        arg0.show();

}

    private void initializeloginpage() {
         login login = new login();
               login.homeStage(primaryStage);
               homeScene = new Scene(login.createScene(this::handleBackButton),500,500);
               login.loginScene(sc);

    }

      private void handleBackButton(){
        primaryStage.setScene(homeScene);
    }        
}
