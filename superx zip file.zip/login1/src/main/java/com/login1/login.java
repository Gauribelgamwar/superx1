package com.login1;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class login extends Application {
    Scene loginScene;
    Stage primaryStage;

    public void homeStage(Stage primaryStage) {

        
    }

    public void setLoginScene(Scene loginScene) {
        this.loginScene = loginScene;
    }

    public void setPrimaryStage1(Stage primaryStage1) {
        this.primaryStage = primaryStage1;
    }

    public VBox createScene(Runnable back){
        Text tx = new Text("Welcome to login page");
        Button pvrButton = new Button("Previou page");
        pvrButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent arg0) {
                back.run();
            }
        Button exploreButton = new Button("Explore page");
        
            
        });

        VBox vb = new VBox(50,tx,pvrButton);
        vb.setStyle("-fx-alignment : top_center");
        return vb;

        
    }

    public void loginScene(Object sc) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'loginScene'");
    }

    @Override
    public void start(Stage arg0) throws Exception {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'start'");
    }
    
}
