package com.login_navigation;

/*import javafx.application.Application;
import javafx.stage.Stage;

public class Main extends Application {
    public static Stage mainStage;
    public static void main(String[] args) {
        System.out.println("Hello world!");

    }
    @Override
    public void start(Stage arg0) throws Exception {
        mainStage = arg0;
        page1.showLogin();
    }
}*/

import javafx.application.Application;
import javafx.stage.Stage;

public class Main {
    public static void main(String[] args) {
        Application.launch(page1.class,args);
    }
}

