package com.login_navigation;


import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class page1 extends Application{
    Text fi=new Text();

    @Override
    public void start(Stage arg0) throws Exception {
      
        Label userLabel = new Label("User Name:");
        TextField userField = new TextField();

        Label passLabel = new Label("Password:");
        PasswordField passField = new PasswordField();

        Button signIn = new Button("Sign In");
        Label message = new Label();

        signIn.setOnAction(e -> {
            String user = userField.getText();
            String pass = passField.getText();

            if (!user.isEmpty() && pass.startsWith("c2w") && pass.length() >= 8) {
              //  page2.showWelcome(user);  
              fi.setText("Login Sucessflullly");

            } else {
                fi.setText("Invalid inputs");
            }
        });

        VBox layout = new VBox(10, userLabel, userField, passLabel, passField, signIn, fi);
        layout.setStyle("-fx-padding: 20; -fx-alignment: center;");
        Scene scene = new Scene(layout, 800, 650);
        arg0.setScene(scene);
        arg0.show();
    }
}

