// package com.login_navigation;

// import javafx.scene.Scene;
// import javafx.scene.control.*;
// import javafx.scene.layout.*;

// public class page2 {

//     public static void showWelcome(String username) {
//         Label welcome = new Label("Welcome " + username + "!!");

//         Button logout = new Button("Logout");
//         logout.setOnAction(e -> page1.showLogin());  
        
//         Button b1 = new Button("Button 1");
//         Button b2 = new Button("Button 2");
//         Button b3 = new Button("Button 3");
//         Button b4 = new Button("Button 4");
//         Button b5 = new Button("Button 5");

//         VBox layout = new VBox(10, welcome, b1, b2, b3, b4, b5, logout);
//         layout.setStyle("-fx-padding: 20; -fx-alignment: center;");
//         Scene scene = new Scene(layout, 300, 350);

//         Main.mainStage.setScene(scene);
//         Main.mainStage.setTitle("Welcome");
//     }
// }
