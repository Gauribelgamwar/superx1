package com.hopebridge3;
import javafx.application.Application;
import javafx.stage.Stage;
public class Main extends Application {
    public static void main(String[] args) {
        System.out.println("Hopebridge project");
        launch(args);
    }
    @Override
    public void start(Stage myStage){
        myStage.show();
    }
}